package java.model;

public class Setup {

	private String nome;

	private String quantidadeArquivos;

	private String descricao;

	private Arquivos arquivos;

}
