package java.model;

public class Usuario extends Pessoa {

	private String nomeUsuario;

	private String senha;

	private PerfilAcesso perfilAcesso;





}
