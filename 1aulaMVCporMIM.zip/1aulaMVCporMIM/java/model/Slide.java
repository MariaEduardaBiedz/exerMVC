package java.model;

public class Slide {

	private String nome;

	private Curso curso;

	private int numeroPaginas;

	private Curso curso;

}
