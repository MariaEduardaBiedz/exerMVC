package java.model;

public class PerfilAcesso {

	private String nome;

	private String descricao;

	private String permissoes;

	private Usuario[] usuarios;

	private Usuario usuario;

}
