package java.model;

public class Apostila {

	private String nome;

	private Curso curso;

	private int numeroPaginas;

	private Curso curso;

}
