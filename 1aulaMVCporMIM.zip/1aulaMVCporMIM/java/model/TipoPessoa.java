package java.model;

public enum TipoPessoa {

	INSTRUTOR,
	ASSISTENTE,
	GERENTE;

}
