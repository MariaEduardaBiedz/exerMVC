package java.model;

import java.util.Date;

public class MaterialDidatico {

	private Date dataEntrega;

	private Date dataRevisao;

	private boolean estaCompleto;

	private Curso curso;

}
