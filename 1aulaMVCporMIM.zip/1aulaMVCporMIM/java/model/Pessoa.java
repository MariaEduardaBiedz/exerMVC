package java.model;

public class Pessoa {

	private String nome;

	private String email;

	private TipoPessoa tipoPessoa;

}
