package java.model;

public class Repositorio {

	private Pessoa resonsavel;

	private String localizacao;

	private Arquivos arquivos;

	private Arquivos arquivos;

}
