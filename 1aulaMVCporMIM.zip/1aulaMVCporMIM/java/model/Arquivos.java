package java.model;

public class Arquivos {

	private String nome;

	private String descricao;

	private String localModelo;

	private Setup setup;

	private Repositorio repositorio;

}
