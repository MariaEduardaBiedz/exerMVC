package com.example.controller;

import com.example.model.Curso;
import com.example.model.Pessoa;
import com.example.model.Slide;
import com.example.model.Apostila;


import java.util.List;


public class CursoController 
{
    private Curso curso;

    public void criarCurso(String nome, Pessoa responsavel, List<Slide> slides, List<Apostila> apostilas) {
        curso = new Curso(nome, responsavel, slides, apostilas);
        // FUTURA implementação para gravar em um banco de dados ou realizar outras operações necessárias.
    }

    public Curso getCurso() 
    {
        return curso;
    }

    
    private Slide slide;
    public void criarSlide(String nome, String curso2, String numeroPaginas) 
    {
        slide = new Slide();
        throw new UnsupportedOperationException("Unimplemented method 'criarSlide'");
    }

    public Slide getSlide() 
    {
        return slide;
    }


    private Apostila apostila;
    public void criarApostila(String nomeApostila, String curso2, String numeroPaginas) 
    {
        apostila = new Apostila();
        throw new UnsupportedOperationException("Unimplemented method 'criarApostila'");
    }

    public Apostila getApostila() 
    {
        return apostila;
    }

    
}
