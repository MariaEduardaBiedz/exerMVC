package com.example.view;

import com.example.controller.CursoController;
import com.example.model.Apostila;
import com.example.model.Pessoa;
import com.example.model.Slide;

import javax.swing.*;
import javax.swing.text.JTextComponent;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class CursoView<SlideController> extends JFrame {
    public JTextField nomeCursoField;
    public JTextField nomeResponsavelField;
    private JComboBox<String>slieComboBox;
    private CursoController controller1;

    private JTextField nomeSlideField;
    public JButton cadastrarButton;
    private SlideController controller2;
   
    private JTextComponent numeroPaginasField;
    private JButton cadastrarnomeApostilaButton;
    private JTextArea nomeApostila;
    private ApostilaController controller3;
    



    public CursoView(CursoController controller) 
    {
        this.controller1 = controller;
        controller1.initUI(this);
    }

    public void SlideView(SlideController controller) 
    {
        this.controller2 = (SlideController) controller;
        controller2.initUI(this);
    }


    private void SlideinitUI() 
    {
        nomeSlideField = new JTextField(20);
        nomeCursoField = new JTextField(20);
        numeroPaginasField = new JTextField(20);

        cadastrarButton = new JButton("Cadastrar Slide");
        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarSlide();
            }
        });


        setLayout(new FlowLayout());
        add(new JLabel("Nome do Slide:"));
        add(nomeSlideField);
        add(new JLabel("Nome do Curso:"));
        add(nomeSlideField);
        add(new JLabel("Número de Páginas:"));
        add(numeroPaginasField);
        add(cadastrarButton);

        pack();
        setTitle("Cadastro de Slide");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }



    public ApostilaView(ApostilaController controller) 
    {
        this.controller3 = controller;
        controller3.initUI(this);
    }

    private void initUI() 
    {
        nomeApostilaField = new JTextField(20);
        nomeCursoField = new JTextField(20);
        numeroPaginasField = new JTextField(20);

        cadastrarButton = new JButton("Cadastrar Apostila");
        cadastrarButton.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
               cadastrarApostila();
            }
        });

        setLayout(new FlowLayout());
        add(new JLabel("Nome da Apostila:"));
        add(nomeSlideField);
        add(new JLabel("Nome do Curso:"));
        add(nomeSlideField);
        add(new JLabel("Número de Páginas:"));
        add(numeroPaginasField);
        add(cadastrarButton);

        pack();
        setTitle("Cadastro de Apostila");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    };



    public void cadastrarCurso() 
    {
        String nomeCurso = nomeCursoField.getText();
        String nomeResponsavel = nomeResponsavelField.getText();

        controller.criarCurso(nomeCurso, new Pessoa(nomeResponsavel));
        
        
        JOptionPane.showMessageDialog(this, "Curso cadastrado com sucesso!");
      
    }

    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(new Runnable() 
        {
            @Override
            public void run() {
                CursoController controller = new CursoController();
                CursoView view = new CursoView(controller);
                view.setVisible(true);
            }
        });
    }


    private void cadastrarSlide() 
    {
        String nome = nomeSlideField.getText();
        JTextComponent nomeCurso2Field;
        String curso2 = nomeCurso2Field.getText();
        String numeroPaginas = numeroPaginasField.getText();

        controller.criarSlide(nome,curso2,numeroPaginas);

        JOptionPane.showMessageDialog(this, "Slide cadastrado com sucesso!");
    }

    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(new Runnable() 
        {
            @Override
            public void run() {
                SlideController controller = new SlideController();
                SlideView view = new SlideView(controller);
                view.setVisible(true);
            }
        });
    }


    private void cadastrarApostila() 
    {
        String nomeApostila = nomeApostilaField.getText();
        String curso = nomeCursoField.getText();
        String numeroPaginas = numeroPaginasField.getText();

        
        controller.criarApostila(nomeApostila,curso,numeroPaginas);

        JOptionPane.showMessageDialog(this, "Apostila cadastrado com sucesso!");

    }

    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(new Runnable() 
        {
            @Override
            public void run() {
                ApostilaController controller = new ApostilaController();
                ApostilaView view = new ApostilaView(controller);
                view.setVisible(true);
            }
        });
    }

}
