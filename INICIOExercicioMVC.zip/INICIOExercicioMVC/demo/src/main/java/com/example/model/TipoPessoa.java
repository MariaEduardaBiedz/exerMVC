package com.example.model;

public enum TipoPessoa {

	INSTRUTOR,
	ASSISTENTE,
	GERENTE;

}
